def greet(name : str):
    return f"hello from the greet program, name : {name}"